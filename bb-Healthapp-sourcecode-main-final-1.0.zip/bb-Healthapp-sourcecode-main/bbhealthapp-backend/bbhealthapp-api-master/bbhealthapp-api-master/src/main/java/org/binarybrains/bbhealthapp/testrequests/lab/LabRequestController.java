package org.binarybrains.bbhealthapp.testrequests.lab;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.binarybrains.bbhealthapp.config.security.UserLoggedInService;
import org.binarybrains.bbhealthapp.exception.AppException;
import org.binarybrains.bbhealthapp.testrequests.TestRequest;
import org.binarybrains.bbhealthapp.testrequests.flow.TestRequestFlow;
import org.binarybrains.bbhealthapp.testrequests.flow.TestRequestFlowService;
import org.binarybrains.bbhealthapp.testrequests.lab.models.CreateLabResult;
import org.binarybrains.bbhealthapp.testrequests.models.RequestStatus;
import org.binarybrains.bbhealthapp.testrequests.services.TestRequestQueryService;
import org.binarybrains.bbhealthapp.testrequests.services.TestRequestUpdateService;
import org.binarybrains.bbhealthapp.users.User;

import javax.validation.ConstraintViolationException;
import java.util.List;

import static org.binarybrains.bbhealthapp.exception.BinaryBrainsResponseStatusException.asBadRequest;
import static org.binarybrains.bbhealthapp.exception.BinaryBrainsResponseStatusException.asConstraintViolation;


@RestController
@RequestMapping("/api/labrequests")
public class LabRequestController {

    Logger log = LoggerFactory.getLogger(LabRequestController.class);




    @Autowired
    private TestRequestUpdateService testRequestUpdateService;

    @Autowired
    private TestRequestQueryService testRequestQueryService;
    @Autowired
    private TestRequestFlowService testRequestFlowService;



    @Autowired
    private UserLoggedInService userLoggedInService;



    @GetMapping("/to-be-tested")
    @PreAuthorize("hasAnyRole('TESTER')")
    public List<TestRequest> getForTests()  {

        return testRequestQueryService.findBy(RequestStatus.INITIATED);

    }

    @GetMapping
    @PreAuthorize("hasAnyRole('TESTER')")
    public List<TestRequest> getForTester()  {


        User user = userLoggedInService.getLoggedInUser();
        return testRequestQueryService.findByTester(user);



    }


    @PreAuthorize("hasAnyRole('TESTER')")
    @PutMapping("/assign/{id}")
    public TestRequest assignForLabTest(@PathVariable Long id) {

        try {
            User user = userLoggedInService.getLoggedInUser();
            TestRequest result = testRequestUpdateService.assignForLabTest(id, user);
            log.info("testRequest updated " + result.toString());
            return result;

        }catch (AppException e) {
            throw asBadRequest(e.getMessage());
        }
    }

    @PreAuthorize("hasAnyRole('TESTER')")
    @PutMapping("/update/{id}")
    public TestRequest updateLabTest(@PathVariable Long id,@RequestBody CreateLabResult createLabResult) {

        try {
            User tester = userLoggedInService.getLoggedInUser();
            TestRequest result = testRequestUpdateService.updateLabTest(id, createLabResult, tester);
            return result;
        } catch (ConstraintViolationException e) {
            throw asConstraintViolation(e);
        }catch (AppException e) {
            throw asBadRequest(e.getMessage());
        }
    }





}
